# PaperBill - Billing Software

A modern, responsive billing software landing page with login, registration, and dashboard functionality.

## Features

- **Interactive Landing Page** with animations
- **Dark/Light Mode Toggle** (persistent)
- **Form Validation** with real-time feedback
- **Password Strength Meter**
- **Dashboard** with stats, invoices, and activity feed
- **Mobile-First** responsive design
- **GSAP Animations** for smooth transitions

## Technologies Used

- HTML5, CSS3, JavaScript
- GSAP (for animations)
- Font Awesome (icons)
- Google Fonts (Poppins)

## Project Structure
paperbill-project/
├── index.html # Homepage
├── login.html # Login Page
├── register.html # Registration Page
├── dashboard.html # User Dashboard
├── style.css # Main Styles
├── script.js # Main JavaScript
├── assets/
│ ├── css/
│ │ └── animations.css # Animation Styles
│ ├── js/
│ │ ├── auth.js # Auth Logic
│ │ ├── dashboard.js # Dashboard Logic
│ │ └── animations.js # Animation Logic
│ ├── images/ # All project images
│ └── fonts/ # Custom Fonts
├── README.md # Documentation
└── .gitignore # Git Ignore File


## How to Run

1. Clone the repository
2. Open `index.html` in a web browser
3. Explore the login/register flow and dashboard

## License

MIT License