// Initialize GSAP animations
document.addEventListener('DOMContentLoaded', () => {
  // Animate hero elements
  gsap.from('.hero-content h1', {
    duration: 1,
    y: 50,
    opacity: 0,
    ease: 'power3.out',
    delay: 0.3
  });

  gsap.from('.hero-content p', {
    duration: 1,
    y: 50,
    opacity: 0,
    ease: 'power3.out',
    delay: 0.6
  });

  gsap.from('.hero-buttons', {
    duration: 1,
    y: 50,
    opacity: 0,
    ease: 'power3.out',
    delay: 0.9
  });

  gsap.from('.hero-image', {
    duration: 1,
    x: 50,
    opacity: 0,
    ease: 'power3.out',
    delay: 0.6
  });

  // Animate feature cards on scroll
  const featureCards = document.querySelectorAll('.feature-card');
  featureCards.forEach((card, index) => {
    gsap.from(card, {
      scrollTrigger: {
        trigger: card,
        start: 'top 80%',
        toggleActions: 'play none none none'
      },
      duration: 0.8,
      y: 50,
      opacity: 0,
      ease: 'power3.out',
      delay: index * 0.1
    });
  });

  // Floating animation for hero image
  gsap.to('.hero-image img', {
    y: 20,
    duration: 3,
    repeat: -1,
    yoyo: true,
    ease: 'sine.inOut'
  });
});