// Form Validation
document.addEventListener('DOMContentLoaded', () => {
  // Password toggle functionality
  document.querySelectorAll('.toggle-password').forEach(toggle => {
    toggle.addEventListener('click', function() {
      const input = this.previousElementSibling;
      const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
      input.setAttribute('type', type);
      this.classList.toggle('fa-eye-slash');
    });
  });

  // Login Form Validation
  const loginForm = document.getElementById('loginForm');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const email = loginForm.querySelector('#email');
      const password = loginForm.querySelector('#password');
      const submitBtn = loginForm.querySelector('button[type="submit"]');
      const btnText = submitBtn.querySelector('.btn-text');
      const btnLoader = submitBtn.querySelector('.btn-loader');
      
      // Reset errors
      resetErrors(loginForm);
      
      // Validate inputs
      let isValid = true;
      
      if (!validateEmail(email.value)) {
        showError(email, 'Please enter a valid email address');
        isValid = false;
      }
      
      if (password.value.length < 6) {
        showError(password, 'Password must be at least 6 characters');
        isValid = false;
      }
      
      if (!isValid) return;
      
      // Show loading state
      btnText.style.display = 'none';
      btnLoader.style.display = 'inline-block';
      submitBtn.disabled = true;
      
      // Simulate API call
      try {
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // On success
        showSuccess('Login successful! Redirecting...');
        setTimeout(() => {
          window.location.href = 'dashboard.html';
        }, 1500);
      } catch (error) {
        // On error
        showError(null, 'Invalid credentials. Please try again.');
        btnText.style.display = 'inline-block';
        btnLoader.style.display = 'none';
        submitBtn.disabled = false;
      }
    });
  }

  // Registration Form Validation
  const registerForm = document.getElementById('registerForm');
  if (registerForm) {
    const passwordInput = registerForm.querySelector('#password');
    
    // Password strength real-time check
    passwordInput.addEventListener('input', function() {
      checkPasswordStrength(this.value);
    });
    
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const name = registerForm.querySelector('#name');
      const email = registerForm.querySelector('#email');
      const password = registerForm.querySelector('#password');
      const confirmPassword = registerForm.querySelector('#confirmPassword');
      const terms = registerForm.querySelector('#terms');
      const submitBtn = registerForm.querySelector('button[type="submit"]');
      const btnText = submitBtn.querySelector('.btn-text');
      const btnLoader = submitBtn.querySelector('.btn-loader');
      
      // Reset errors
      resetErrors(registerForm);
      
      // Validate inputs
      let isValid = true;
      
      if (name.value.trim().length < 3) {
        showError(name, 'Please enter your full name');
        isValid = false;
      }
      
      if (!validateEmail(email.value)) {
        showError(email, 'Please enter a valid email address');
        isValid = false;
      }
      
      const passwordStrength = calculatePasswordStrength(password.value);
      if (passwordStrength < 70) {
        showError(password, 'Please choose a stronger password');
        isValid = false;
      }
      
      if (password.value !== confirmPassword.value) {
        showError(confirmPassword, 'Passwords do not match');
        isValid = false;
      }
      
      if (!terms.checked) {
        showError(terms, 'You must agree to the terms and conditions');
        isValid = false;
      }
      
      if (!isValid) return;
      
      // Show loading state
      btnText.style.display = 'none';
      btnLoader.style.display = 'inline-block';
      submitBtn.disabled = true;
      
      // Simulate API call
      try {
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // On success
        showSuccess('Registration successful! Redirecting to login...');
        setTimeout(() => {
          window.location.href = 'login.html';
        }, 1500);
      } catch (error) {
        // On error
        showError(null, 'Registration failed. Please try again.');
        btnText.style.display = 'inline-block';
        btnLoader.style.display = 'none';
        submitBtn.disabled = false;
      }
    });
  }
});

// Helper Functions
function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

function calculatePasswordStrength(password) {
  let strength = 0;
  
  // Length contributes up to 40%
  strength += Math.min(40, (password.length / 12) * 40);
  
  // Character variety contributes up to 60%
  const hasLower = /[a-z]/.test(password);
  const hasUpper = /[A-Z]/.test(password);
  const hasNumber = /\d/.test(password);
  const hasSpecial = /[^a-zA-Z0-9]/.test(password);
  
  const varietyCount = [hasLower, hasUpper, hasNumber, hasSpecial].filter(Boolean).length;
  strength += (varietyCount / 4) * 60;
  
  return Math.min(100, strength);
}

function checkPasswordStrength(password) {
  const strength = calculatePasswordStrength(password);
  const meter = document.querySelector('.strength-meter');
  const text = document.querySelector('.strength-text');
  const hints = document.querySelectorAll('.password-hints li');
  
  if (!meter) return;
  
  // Update strength meter
  meter.style.width = `${strength}%`;
  
  // Update strength text and color
  let strengthText = '';
  let strengthColor = '';
  
  if (strength < 30) {
    strengthText = 'Weak';
    strengthColor = '#ff4444';
  } else if (strength < 70) {
    strengthText = 'Medium';
    strengthColor = '#ffbb33';
  } else {
    strengthText = 'Strong';
    strengthColor = '#00C851';
  }
  
  if (text) {
    text.textContent = strengthText;
    text.style.color = strengthColor;
  }
  
  meter.style.backgroundColor = strengthColor;
  
  // Update password hints
  hints.forEach(hint => {
    const requirement = hint.getAttribute('data-requirement');
    const icon = hint.querySelector('i');
    
    let isMet = false;
    switch (requirement) {
      case 'length':
        isMet = password.length >= 8;
        break;
      case 'uppercase':
        isMet = /[A-Z]/.test(password);
        break;
      case 'number':
        isMet = /\d/.test(password);
        break;
      case 'special':
        isMet = /[^a-zA-Z0-9]/.test(password);
        break;
    }
    
    if (isMet) {
      hint.classList.add('met');
      icon.classList.add('fa-check');
      icon.classList.remove('fa-times');
    } else {
      hint.classList.remove('met');
      icon.classList.remove('fa-check');
      icon.classList.add('fa-times');
    }
  });
}

function showError(input, message) {
  let formGroup;
  
  if (input instanceof HTMLElement) {
    formGroup = input.closest('.form-group');
  } else if (typeof input === 'string') {
    // Handle checkbox case
    formGroup = document.getElementById(input).closest('.form-group');
  }
  
  if (formGroup) {
    formGroup.classList.add('error');
    const errorElement = formGroup.querySelector('.error-message');
    if (errorElement) {
      errorElement.textContent = message;
      errorElement.style.display = 'block';
      
      // Add shake animation
      formGroup.style.animation = 'none';
      void formGroup.offsetWidth; // Trigger reflow
      formGroup.style.animation = 'shake 0.5s ease';
    }
  } else if (message) {
    // Show general error message
    showAlert('error', message);
  }
}

function showSuccess(message) {
  showAlert('success', message);
}

function showAlert(type, message) {
  const alert = document.createElement('div');
  alert.className = `alert alert-${type}`;
  alert.innerHTML = `
    <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
    <span>${message}</span>
  `;
  
  const authForm = document.querySelector('.auth-form');
  if (authForm) {
    authForm.prepend(alert);
    
    // Show alert
    setTimeout(() => {
      alert.classList.add('show');
    }, 10);
    
    // Hide after 5 seconds
    setTimeout(() => {
      alert.classList.remove('show');
      setTimeout(() => {
        alert.remove();
      }, 300);
    }, 5000);
  }
}

function resetErrors(form) {
  form.querySelectorAll('.form-group').forEach(group => {
    group.classList.remove('error');
    const errorElement = group.querySelector('.error-message');
    if (errorElement) {
      errorElement.style.display = 'none';
    }
  });
  
  // Remove any existing alerts
  document.querySelectorAll('.alert').forEach(alert => {
    alert.remove();
  });
}