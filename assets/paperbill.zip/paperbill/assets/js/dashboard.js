document.addEventListener('DOMContentLoaded', () => {
  // Toggle sidebar on mobile
  const sidebarToggle = document.createElement('div');
  sidebarToggle.className = 'sidebar-toggle';
  sidebarToggle.innerHTML = '<i class="fas fa-bars"></i>';
  document.querySelector('.main-header').prepend(sidebarToggle);
  
  sidebarToggle.addEventListener('click', () => {
    document.querySelector('.dashboard').classList.toggle('sidebar-collapsed');
  });
  
  // Initialize chart (using Chart.js if available)
  if (typeof Chart !== 'undefined') {
    const ctx = document.getElementById('revenueChart');
    if (ctx) {
      new Chart(ctx, {
        type: 'line',
        data: {
          labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
          datasets: [{
            label: 'Revenue',
            data: [45000, 52000, 48000, 62000, 75000, 84500],
            backgroundColor: 'rgba(74, 107, 255, 0.1)',
            borderColor: '#4a6bff',
            borderWidth: 2,
            tension: 0.3,
            fill: true
          }]
        },
        options: {
          responsive: true,
          plugins: {
            legend: {
              display: false
            }
          },
          scales: {
            y: {
              beginAtZero: true
            }
          }
        }
      });
    }
  }
  
  // Notification dropdown
  const notifications = document.querySelector('.notifications');
  if (notifications) {
    const dropdown = document.createElement('div');
    dropdown.className = 'notification-dropdown';
    dropdown.innerHTML = `
      <div class="notification-header">
        <h4>Notifications</h4>
        <span class="mark-all">Mark all as read</span>
      </div>
      <ul class="notification-list">
        <li class="unread">
          <div class="notification-icon">
            <i class="fas fa-file-invoice"></i>
          </div>
          <div class="notification-content">
            <p>New invoice from <strong>Rajesh Electronics</strong></p>
            <span class="notification-time">10 min ago</span>
          </div>
        </li>
        <li>
          <div class="notification-icon">
            <i class="fas fa-rupee-sign"></i>
          </div>
          <div class="notification-content">
            <p>Payment received for <strong>INV-2023-002</strong></p>
            <span class="notification-time">2 hours ago</span>
          </div>
        </li>
        <li>
          <div class="notification-icon">
            <i class="fas fa-exclamation-triangle"></i>
          </div>
          <div class="notification-content">
            <p><strong>INV-2023-004</strong> is overdue</p>
            <span class="notification-time">1 day ago</span>
          </div>
        </li>
      </ul>
      <div class="notification-footer">
        <a href="#">View all notifications</a>
      </div>
    `;
    
    notifications.appendChild(dropdown);
    
    notifications.addEventListener('click', (e) => {
      e.stopPropagation();
      dropdown.classList.toggle('show');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', () => {
      dropdown.classList.remove('show');
    });
  }
  
  // User profile dropdown
  const userAvatar = document.querySelector('.user-avatar');
  if (userAvatar) {
    const dropdown = document.createElement('div');
    dropdown.className = 'profile-dropdown';
    dropdown.innerHTML = `
      <div class="profile-header">
        <img src="assets/images/testimonial-user.webp" alt="User">
        <div class="profile-info">
          <h4>John Doe</h4>
          <p>john@example.com</p>
        </div>
      </div>
      <ul class="profile-links">
        <li><a href="#"><i class="fas fa-user"></i> Profile</a></li>
        <li><a href="#"><i class="fas fa-cog"></i> Settings</a></li>
        <li><a href="#"><i class="fas fa-question-circle"></i> Help</a></li>
      </ul>
      <div class="profile-footer">
        <a href="login.html"><i class="fas fa-sign-out-alt"></i> Logout</a>
      </div>
    `;
    
    userAvatar.appendChild(dropdown);
    
    userAvatar.addEventListener('click', (e) => {
      e.stopPropagation();
      dropdown.classList.toggle('show');
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', () => {
      dropdown.classList.remove('show');
    });
  }
  
  // Animate stats cards
  const statCards = document.querySelectorAll('.stat-card');
  statCards.forEach(card => {
    const valueElement = card.querySelector('h3');
    const targetValue = parseInt(valueElement.textContent.replace(/[^0-9]/g, ''));
    let currentValue = 0;
    
    const animateValue = () => {
      if (currentValue < targetValue) {
        currentValue += Math.ceil(targetValue / 50);
        if (currentValue > targetValue) currentValue = targetValue;
        
        if (valueElement.textContent.includes('₹')) {
          valueElement.textContent = `₹${currentValue.toLocaleString()}`;
        } else {
          valueElement.textContent = currentValue;
        }
        
        requestAnimationFrame(animateValue);
      }
    };
    
    // Start animation when card is in view
    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting) {
        animateValue();
        observer.unobserve(card);
      }
    });
    
    observer.observe(card);
  });
});